(function($) {
    'use strict';
    var typed3 = new Typed('.element3', {
        strings: [' Zirmed, Waystar, Avality, Optum, GetwayEDI, Navicure, Emdeon, Office Ally'],
        smartBackspace: true,
        loop: true,
        typeSpeed: 50
    });
})(jQuery);