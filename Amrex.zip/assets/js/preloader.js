jQuery(document).ready(function($) {
    jQuery("#load").fadeOut(200);
    jQuery("#loading").delay(200).fadeOut(200);
});